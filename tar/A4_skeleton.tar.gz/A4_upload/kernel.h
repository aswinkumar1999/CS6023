int schedule(int N, int M, int* arrival_times, int* burst_times, int** cores_schedules, int* cs_lengths);
